require('dotenv').config();
const express=require('express');
const TelegramBot=require('node-telegram-bot-api');
const app=express();
const bot=new TelegramBot(process.env.BOT_TOKEN,{polling:true});
require('./bot/router')(bot);
app.get('/',(req,res)=>res.send('Semja Bot OK'));
app.listen(process.env.PORT||3000);
