const fs=require('fs');
const path=require('path');
const file=path.join(__dirname,'../data/transactions.json');
function read(){try{return JSON.parse(fs.readFileSync(file,'utf8'));}catch{return [];}}
function write(d){fs.writeFileSync(file,JSON.stringify(d,null,2));}
function addTransaction(tx){const a=read();tx.id=Date.now();a.push(tx);write(a);}
module.exports={addTransaction,read};