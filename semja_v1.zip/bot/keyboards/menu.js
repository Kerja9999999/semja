module.exports={reply_markup:{keyboard:[
['💰 Добавить расход','💵 Добавить доход'],
['📊 Статистика'],
['⚙️ Настройки']
],resize_keyboard:true,persistent_keyboard:true}};