const menu=require('./keyboards/menu');
const cats=require('./keyboards/expense');
const states=require('./state');
const {addTransaction}=require('../services/storage');

module.exports=(bot)=>{
bot.onText(/\/start/,(msg)=>{
delete states[msg.chat.id];
bot.sendMessage(msg.chat.id,'🏠 Семейный бюджет',menu);
});

bot.on('message',(msg)=>{
const id=msg.chat.id;
const t=msg.text;
if(!t||t==='/start') return;

if(t==='💰 Добавить расход'){
states[id]={step:'category',type:'expense'};
return bot.sendMessage(id,'Выберите категорию',cats);
}

if(t==='❌ Отмена'){
delete states[id];
return bot.sendMessage(id,'Отменено',menu);
}

if(!states[id]) return;

if(states[id].step==='category'){
states[id].category=t;
states[id].step='amount';
return bot.sendMessage(id,'Введите сумму');
}

if(states[id].step==='amount'){
const n=Number(t.replace(',','.'));
if(isNaN(n)) return bot.sendMessage(id,'Введите число');
states[id].amount=n;
states[id].step='description';
return bot.sendMessage(id,'Введите описание');
}

if(states[id].step==='description'){
addTransaction({
type:'expense',
category:states[id].category,
amount:states[id].amount,
description:t,
chatId:id,
date:new Date().toISOString()
});
delete states[id];
return bot.sendMessage(id,'✅ Сохранено',menu);
}
});
};